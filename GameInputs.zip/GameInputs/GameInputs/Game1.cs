﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Text;
namespace GameInputs
{
   /// <summary>
   /// This is the main type for your game.
   /// </summary>
   public class Game1 : Game
   {
      GraphicsDeviceManager graphics;
      SpriteBatch spriteBatch;
      Vector2 position;
      Texture2D texture;
      KeyboardState previousState;



      public Game1()
      {
         graphics = new GraphicsDeviceManager(this);
         Content.RootDirectory = "Content";

      }

      protected override void Initialize()
      {
         base.Initialize();
         position = new Vector2(0,0 );
         previousState = Keyboard.GetState();
      }

      protected override void LoadContent()
      {
         spriteBatch = new SpriteBatch(GraphicsDevice);
         texture = this.Content.Load<Texture2D>("Char1");
      }

      protected override void UnloadContent()
      {
      }

      protected override void Update(GameTime gameTime)
      {
         // Poll for current keyboard state
         KeyboardState state = Keyboard.GetState();

         // If they hit esc, exit
         if (state.IsKeyDown(Keys.Escape))
            Exit();
                     

         // Print to debug console currently pressed keys
         System.Text.StringBuilder sb = new StringBuilder();
         foreach (var key in state.GetPressedKeys())
            sb.Append("Key: ").Append(key).Append(" pressed ");

         if (sb.Length > 0)
            System.Diagnostics.Debug.WriteLine(sb.ToString());
         else
            System.Diagnostics.Debug.WriteLine("No Keys pressed");

         if (state.IsKeyDown(Keys.Right))
            position.X += 2;
         if (state.IsKeyDown(Keys.Left) & !previousState.IsKeyDown(Keys.Left))
      
            position.X -= 2;
         if (state.IsKeyDown(Keys.Up))
            position.Y -= 2;
         if (state.IsKeyDown(Keys.Down))
            position.Y += 2;

         base.Update(gameTime);
         previousState = state;
      }

      protected override void Draw(GameTime gameTime)
      {
         GraphicsDevice.Clear(Color.CornflowerBlue);

         spriteBatch.Begin();
         spriteBatch.Draw(texture, position);
         spriteBatch.End();
         base.Draw(gameTime);
      }
   }
}
